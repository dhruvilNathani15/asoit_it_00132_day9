var x=50,y=20;
var z = x+y;
var x=50,y=20;
var a = x-y;
var x=30,y=10;
var b = x*y;

console.log("sum of  x+y is:",z);
document.write("<br>")
document.write("sum of x+y is:",z);


console.log("sum of x-y is",a);
document.write("<br>")
document.write("sum of x-y is:",a);

console.log("sum of x*y is",b);
document.write("<br>")
document.write("sum of x*y is:",b);
 
var a=["dhruvil", "nathani"];
document.write(a  instanceof Array);
document.write("<br/>");

class rectangle {
    constructor(Height,width){
        this.Height = Height;
        this.width = width;

    }
}

var r=new rectangle(10,20);
document.write(r instanceof rectangle);
document.write("<br/>");
document.write(r.Height+r.width);
document.write("<br/>");

let s1 = "dhruvil";
let s2 = "nathani";
let s3 = s1 + " " + s2;
document.write(s3)


